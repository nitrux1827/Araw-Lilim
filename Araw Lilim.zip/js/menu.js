menuGame = {
	create:function(){
		menumusic = game.add.audio("bgMusic1");
		menumusic.loop = true;
		menumusic.play();

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
		game.scale.forceLandscape = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.pageAlignVertically = true;
		game.scale.setScreenSize =true;

		bg = game.add.image(1,-90,"Menu");
		bg.scale.y = 2;

		start = game.add.image(205,120,"ArawLilim");
		start.scale.y = 1.6;
		start.scale.x = 1.4;

		startButton = game.add.button(game.width/2.3,game.height/1.9, "buttonplay",this.buttonPlay);
		
		aboutText = game.add.button(310,430,"About1",this.about);
        aboutText.anchor.set(0.6);
		aboutText.scale.set(1);  
			
		instruc = game.add.button(500,430,"Ins1",this.ins);
		instruc.anchor.set(0.6);
		instruc.scale.set(1);
			
	},

	about: function(){
            about=game.add.image(0,0,"About2");
            about.scale.set(3.2);
		
			
            restartButton=game.add.button(350,30,"menu2",restartB,this);
            function restartB() {
           
            restartButton.destroy();
            game.state.start("menuGame");
            }

            },
    ins: function(){
            about=game.add.image(0,0,"Ins2");
            about.scale.set(3.2);
			

            restartButton=game.add.button(350,550,"menu2",restartB,this);
            function restartB() {
            restartButton.destroy();

            game.state.start("menuGame");

            }

            },

	update:function(){
		// if(keyboard.up.isDown){
		// 	game.state.start("playGame");
		},
	buttonPlay:function(){
				game.state.start("playGame");
				menumusic.stop();
				},
	}