preloadGame = {
preload:function() {
    game.load.image("bg","img/bg.png");
    game.load.image("Menu","img/menu.png");
    game.load.image("diamond","img/diamond.png"); 
    game.load.spritesheet('buttonplay', 'img/play-btn.png', 120, 50);
    game.load.spritesheet("player","img/player.png",30,30);
    game.load.spritesheet("enemy1","img/enemy1.png",40,40);
    game.load.spritesheet("enemy2","img/enemy2.png",40,40);
    game.load.spritesheet("enemy3","img/enemy3.png",40,40);
    game.load.image("platform1","img/plat1.png");
    game.load.image("platform2","img/plat2.png");
    game.load.image("platform3","img/plat3.png");
    game.load.image("platform4","img/plat4.png");
    game.load.image("platform5","img/plat5.png");
    game.load.image("buttonleft","img/btn-left.png",50,50);
    game.load.image("buttonright","img/btn-right.png",50,50);
    game.load.image("buttonup","img/btn-up.png",50,50);
    game.load.image("buttondown","img/btn-down.png",50,50);
    game.load.image('About1','img/about1.png');
    game.load.image('About2','img/about2.png');
    game.load.image('Ins1','img/instruction1.png');
    game.load.image('Ins2','img/instruction2.png');
    game.load.spritesheet("menu2","img/backtomenu.png");
    game.load.image('Go','img/go.png');
    game.load.image('ArawLilim','img/arawlilim.png');
    game.load.image("restart","img/restart.png");
    game.load.audio('bgMusic1', 'audio/menubgmusic.mp3');
    game.load.image('pause','img/pause.png');
},
create:function(){
    game.state.start("playGame");
    game.state.start("menuGame");
},
}