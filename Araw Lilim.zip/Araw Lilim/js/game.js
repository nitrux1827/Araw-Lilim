var w = 800, h = 600;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');
var player, enemy1, enemy2, enemy3, keyboard, startButton, restartButton, playing;
var button, platform1,platform2,platform3,platform4,platform5;
var bounds = 10000;
var btn, score;
var bestText, timeText, scoreText;
var gameOverText, bestScoreText; 
var diamond, shineDiamond, shineDiamonds;

game.state.add("bootGame", bootGame);
game.state.add("preloadGame", preloadGame);
game.state.add("menuGame", menuGame);
game.state.add("playGame", playGame);

game.state.start("bootGame");